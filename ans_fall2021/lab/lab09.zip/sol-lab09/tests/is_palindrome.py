test = {
  'name': 'is_palindrome',
  'points': 0,
  'suites': [
    {
      'type': 'concept',
      'cases': [
        {
          'question': 'The is_palindrome function runs in ____ time in the length of its input.',
          'answer': 'Linear',
          'choices': [
              'Constant',
              'Logarithmic',
              'Linear',
              'Quadratic',
              'Exponential',
              'None of these'
          ]
        },
      ]
    }
  ]
}