import re


def calculator_ops(calc_str):
    """
    Finds expressions from the Calculator language that have two
    numeric operands and returns the expression without the parentheses.

    >>> calculator_ops("(* 2 4)")
    ['* 2 4']
    >>> calculator_ops("(+ (* 3 (+ (* 2 4) (+ 3 5))) (+ (- 10 7) 6))")
    ['* 2 4', '+ 3 5', '- 10 7']
    >>> calculator_ops("(* 2)")
    []
    """
    # Since hyphen is a special character inside [], it must be escaped
    return re.findall(r"\(([+\-/*]\s+\d+\s+\d+)\)", calc_str)

    # Alternate solution: hyphen must be at either beginning or end inside []
    return re.findall(r"\(([-+*/]\s+\d+\s+\d+)\)", calc_str)
