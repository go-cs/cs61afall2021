test = {
  'name': 'double',
  'points': 1,
  'suites': [
    {
      'type': 'sqlite',
      'setup': """
      sqlite> .read lab14.sql
      """,
      'cases': [
        {
          'locked': False,
          'code': r"""
          sqlite> SELECT * FROM double;
          breakfast|dinner|La Val's
          breakfast|dinner|Sliver
          breakfast|snack|La Val's
          lunch|snack|La Val's
          """,
        },
      ],
    },
  ]
}